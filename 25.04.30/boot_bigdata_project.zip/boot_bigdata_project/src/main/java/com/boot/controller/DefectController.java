package com.boot.controller;

import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.boot.dto.BoardDTO;
import com.boot.dto.CommentDTO;
import com.boot.dto.Defect_ReportsDTO;
import com.boot.service.DefactService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class DefectController {
	@Autowired
    private DefactService defactservice;
	
	
	@RequestMapping("/insertDefect")
	public String insertDefect(Defect_ReportsDTO defect_ReportsDTO) {
		log.info("@# insertDefect()");
		log.info("@# defect_ReportsDTO=>"+defect_ReportsDTO);
		
		defactservice.insertDefect(defect_ReportsDTO);
		
		return "redirect:defect_reports_ok";
	}
	
	
    @GetMapping("/selectDefectreport")
    public String selectDefectreport(@RequestParam("id") int id, Model model) {
        log.info("@# Controller: selectDefectreport id => " + id);

        List<Defect_ReportsDTO> defectList = defactservice.selectDefectreport(id);
        
        // 단일 결과
        if (!defectList.isEmpty()) {
            Defect_ReportsDTO dto = defectList.get(0);
            model.addAttribute("defectList", defectList);
        }

        log.info("@# defectList => " + defectList);
        return "defect_details_check";  // 보여줄 JSP 
    }
	


	

	
	

	@RequestMapping("/defect_reports")
	public String list(Model model) {
		log.info("@#defect_reports");
		
		return "defect_reports";
	}
	
	@RequestMapping("/defect_reports_ok")
	public String defect_reports_ok(Model model) {
		log.info("@#defect_reports");
		return "defect_reports_ok";
	}
	
	@RequestMapping("/defect_details_check")
	public String defect_details_check(Model model) {
		log.info("@#defect_details_check");
		return "defect_details_check";
	}
	
	@RequestMapping("/defect_list")
	public String defect_list(Model model) {
		log.info("@#defect_list");
		return "defect_list";
	}
	
	@RequestMapping("/defect_detail")
	public String defect_detail(Model model) {
		log.info("@#defect_detail");
		return "defect_detail";
	}
//	
}
