package com.boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootBigdataProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
