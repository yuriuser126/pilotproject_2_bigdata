package com.boot.service;

public interface RecallService {
	 public String getRecallInfo(String vehicleNumber);
}
